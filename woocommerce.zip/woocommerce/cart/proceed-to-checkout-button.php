<?php

/**
 * Proceed to checkout button
 *
 * Contains the markup for the proceed to checkout button on the cart.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/proceed-to-checkout-button.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 2.4.0
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

$home = get_home_url();
$urlTienda = $home . '/tienda';

?>

<div class="proceedToCheckoutButtonBox">
	<a id="continueShoppingButton" href="<?php echo $urlTienda; ?>"></a>
</div>

<div class="proceedToCheckoutButtonBox">

	<a href="<?php echo esc_url(wc_get_checkout_url()); ?>">
		<?php esc_html_e('Proceed to checkout', 'woocommerce'); ?>
	</a>
</div>

<style>
	.wc-proceed-to-checkout {
		display: flex;
		align-items: center;
		flex-wrap: wrap;
	}

	.proceedToCheckoutButtonBox {
		width: 45%;
		margin-top: 30px;
		margin-bottom: 30px;
		cursor: pointer;
	}

	.proceedToCheckoutButtonBox a {
		width: 100%;
		height: 100%;
		text-align: center;
		background-color: #d91887;
		color: white;
		padding: 10px;
		font-size: 16px;
		font-weight: bold;
		cursor: pointer;
		border-style: solid;
		border-width: 2px;
		border-radius: 23px;
		border-color: #d91887;
	}

	.proceedToCheckoutButtonBox a:hover {
		background-color: white;
		color: #d91887;
	}
</style>